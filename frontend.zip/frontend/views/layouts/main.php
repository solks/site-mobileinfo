<?php
use yii\helpers\Html;
use yii\bootstrap\Nav;
use yii\bootstrap\NavBar;
use yii\widgets\Breadcrumbs;
use frontend\assets\AppAsset;
use frontend\widgets\Alert;

/* @var $this \yii\web\View */
/* @var $content string */

AppAsset::register($this);
?>
<?php $this->beginPage() ?>
<!DOCTYPE html>
<html lang="<?= Yii::$app->language ?>">
<head>
	<meta charset="<?= Yii::$app->charset ?>"/>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link href='https://fonts.googleapis.com/css?family=Open+Sans:300&subset=latin,cyrillic' rel='stylesheet' type='text/css'>
	<?= Html::csrfMetaTags() ?>
	<title><?= Html::encode($this->title) ?></title>
	<?php $this->head() ?>
</head>
<body>
	<?php $this->beginBody() ?>
	<div class="container">
		<div id="header" class="row">
			<div class="col-sm-6"><img id="logo" class="img-rounded" src="logo.png"></div>
			<div class="col-sm-6">
				<form class="navbar-form navbar-left" role="search">
					<input type="text" class="form-control" placeholder=" ">
					<button type="submit" class="btn btn-default">Search</button>
				</form>
				<img src="tips.png">
			</div>
		</div>
		<div id="cat-line" class="row">
			<div class="col-sm-2">
			</div>
			<div class="col-sm-10 categories">
				<a href="#">Samsung</a>
				<a href="#">Lenovo</a>
				<a href="#">ASUS</a>
			</div>
		</div>
		<div id="blog-slider" class="row">
			<div id="blog-cover" class="col-sm-2">
				<div class="cover-bookmark"><span class="bookmark-label glyphicon glyphicon-pencil"></span> <a href="#" class="bookmark-title">Блог</a></div>
			</div>
			<div class="col-sm-10 slider-content">
				<img class="blog-pwimage pull-left" src="images/blog/n1.jpg">
				<a href="#"><h3>Пять полезных офисных пакетов для Android</h3></a>
				<p>Современные смартфоны планшеты уже давно перестали быть просто высокотехнологичными игрушками. Главная особенность этих устройств — сенсорные экраны, при помощи которых можно выполнять вполне серьёзные задачи. Множество различных приложений, размещённых в Google Play, помогут приспособить ваш смартфон или планшет для выполнения практически любой работы...</p>
			</div>
		</div>
		<div class="row">
			<div id="sort-labels" class="col-sm-2">
				<div class="row">
					<div id="tags-cover" class="col-sm-12">
						<div class="cover-bookmark"><span class="bookmark-label glyphicon glyphicon-tags"></span> <a href="#" class="bookmark-title">Теги</a></div>
					</div>
				</div>
				<div class="row">
					<div id="rposts-cover" class="col-sm-12">
						<div class="cover-bookmark"><span class="bookmark-label glyphicon glyphicon-list-alt"></span> <a href="#" class="bookmark-title">Статьи</a></div>
					</div>
				</div>
			</div>
			<div class="col-sm-10">
				<div class="row">
					<div id="tags" class="col-sm-12">
						<h2 class="text-center">Теги</h2>
						<p class="text-center">
							<a class="label label-tag-na" href="#">Интернет</a>
							<a class="label label-tag" href="#" role="button">Интерфейс</a>
							<a class="label label-tag-na" href="#" role="button">Карта памяти</a>
							<a class="label label-tag" href="#" role="button">Контакты</a>
							<a class="label label-tag-na" href="#" role="button">Настройка Android</a>
							<a class="label label-tag" href="#" role="button">Обновление</a>
							<a class="label label-tag-na" href="#" role="button">Оформление</a>
							<a class="label label-tag" href="#" role="button">Приложения</a>
							<a class="label label-tag" href="#" role="button">Разное</a>
							<a class="label label-tag" href="#" role="button">Синхронизация</a>
							<a class="label label-tag-na" href="#" role="button">Сообщения</a>
						</p>
					</div>
				</div>
			</div>
		</div>
		<div class="row">
			<div id="content-sidebar" class="col-sm-2"></div>
			<div class="col-sm-10">
				<?= $content ?>
			</div>
		</div>
		<div>
			
		</div>
		<footer class="footer">
			<div>
			<p class="pull-left">&copy; My Company <?= date('Y') ?></p>
			<p class="pull-right"><?= Yii::powered() ?></p>
			</div>
		</footer>
	
	</div>

	<?php $this->endBody() ?>
</body>
</html>
<?php $this->endPage() ?>
